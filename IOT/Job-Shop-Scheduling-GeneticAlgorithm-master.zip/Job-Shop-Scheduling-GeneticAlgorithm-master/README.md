# Job Shop Scheduling

Job shop Scheduling using Genetic Algorithm.

Added static Processing time and Job Sequence in ```data``` folder, you can change number of machines and number of jobs according to your problem.

*Find Genetic Algorithm code in* ``` .ipynb file```


### Schedule using Gantt Chart -
![schedule](Schedule_chart/gantt_chart.png)
