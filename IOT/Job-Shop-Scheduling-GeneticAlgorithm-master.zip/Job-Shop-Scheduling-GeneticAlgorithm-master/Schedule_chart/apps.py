from django.apps import AppConfig


class ScheduleApiConfig(AppConfig):
    name = 'schedule_api'
